# transpose

```bash
mkdir build
cd build
cmake ..
make -j
./my_transpose
```